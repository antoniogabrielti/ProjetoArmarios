
package util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DateUtil {
    public static Date stringToDate(String data) throws ParseException{
        return(new SimpleDateFormat("dd/MM/yyyy").parse(data));
    }    
    public static String dateToString(Date data){
        return(new SimpleDateFormat("dd/MM/yyyy").format(data));
    }
    
    public static boolean verificaData(String data){
        return(data.matches("\\d{2}/\\d{2}/\\d{4}"));
    }
}
